@import UIKit;

@interface ViewController : UITableViewController
@property(strong, nonatomic) NSArray *content;
@end
