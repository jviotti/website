@import UIKit;

@interface DetailsController : UIViewController

@property(strong, nonatomic) NSString *content;

- (id)initWithText:(NSString *)details;

@end
